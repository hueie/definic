# -*- coding: utf-8 -*-

LONG = 1
SHORT = -1
HOLD = 0
