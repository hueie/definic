from django import forms

class LinearGraphForm(forms.Form):
    pStockcode = forms.CharField()
