from django.apps import AppConfig


class InvestConfig(AppConfig):
    name = 'invest'
