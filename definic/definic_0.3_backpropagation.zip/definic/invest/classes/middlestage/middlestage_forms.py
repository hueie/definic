from django import forms

class AlphamodelForm(forms.Form):
    pStock_code = forms.CharField()

   