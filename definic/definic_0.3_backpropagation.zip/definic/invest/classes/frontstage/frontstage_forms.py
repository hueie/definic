from django import forms

class PortfoliobuilderForm(forms.Form):
    pStock_code = forms.CharField()

