from django.shortcuts import render, redirect
from chartit import	DataPool, Chart
from .models import	*

from .definic.crudeoil import Crudeoil

def	index(request):
	from .models import	CrudeOilModel
	
	cdo	= Crudeoil()
	crudeoilDataf =	cdo.analysis()
	chartsrc = cdo.getObjSrc()
	
	CrudeOilModel.objects.all().delete()

	if	CrudeOilModel.objects.count() == 0:
		for	i in range(len(chartsrc['Date'])):
			com = CrudeOilModel.objects.create(
				Date = chartsrc['Date'][i], 
				Open = chartsrc['Open'][i]/100, 
				High = chartsrc['High'][i]/100, 
				Low = chartsrc['Low'][i]/100, 
				Close = chartsrc['Close'][i]/100, 
				Adj_Close = chartsrc['Adj Close'][i]/100, 
				Volume = chartsrc['Volume'][i]/1000000, 
				Log_Ret = chartsrc['Log_Ret'][i]*100, 
				Volatility = chartsrc['Volatility'][i]*100
				)
			com.save()

	ds = DataPool(
	   series=
		[{'options': {
			'source': CrudeOilModel.objects.all()},
		  'terms': [
			'Date',
			'Open',
			'High',
			'Low',
			'Close',
			'Adj_Close',
			'Volume',
			'Log_Ret',	
			'Volatility']}
		 ])

	cht	= Chart(
			datasource = ds, 
			series_options = 
			  [{'options':{
				  'type': 'line',
				  'stacking': False},
				'terms':{
				  'Date': [
					'Open',
					'High',
					'Low',
					'Close',
					'Adj_Close',
					'Volume',
					'Log_Ret',	
					'Volatility']
				  }}],
			chart_options =	
			  {'title':	{
				   'text': 'Oil	Data of	New	York Stock Market'},
			   'xAxis':	{
					'title': {
					   'text': 'Date of	All	Opening	'}}},
			x_sortf_mapf_mts = None
		)
	
	maintitle =	'Oil Analysis'
	subtitle = 'Oil Data Chart in	NY Stock Market'
	context	= {'stockchart':cht, 'maintitle': maintitle, 'subtitle': subtitle,}
	return render(request, 'index.html', context)


def	index2(request):
	testds = MonthlyWeatherByCity.objects.all()[0].boston_temp

	ds = DataPool(
	   series=
		[{'options': {
			'source': MonthlyWeatherByCity.objects.all()},
		  'terms': [
			'month',
			'houston_temp',	
			'boston_temp']}
		 ])
 
	def	monthname(month_num):
		names ={1: 'Jan', 2: 'Feb',	3: 'Mar', 4: 'Apr',	5: 'May', 6: 'Jun',
				7: 'Jul', 8: 'Aug',	9: 'Sep', 10: 'Oct', 11: 'Nov',	12:	'Dec'}
		return names[month_num]

	cht	= Chart(
			datasource = ds, 
			series_options = 
			  [{'options':{
				  'type': 'line',
				  'stacking': False},
				'terms':{
				  'month': [
					'boston_temp',
					'houston_temp']
				  }}],
			chart_options =	
			  {'title':	{
				   'text': 'Weather	Data of	Boston and Houston'},
			   'xAxis':	{
					'title': {
					   'text': 'Month'}}},
			x_sortf_mapf_mts = (None, monthname, False)
		)

	context	= {	'weatherchart':cht,	 }
	return render(request, 'index.html', context)